﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace amp12b_1083_stp.Model
{
    public class Musteri
    {
    }
}
